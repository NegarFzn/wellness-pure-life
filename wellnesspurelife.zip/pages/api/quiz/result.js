// pages/api/quiz/result.js
import { MongoClient } from "mongodb";

// MongoDB connection string and database name
const uri = process.env.MONGODB_URI;
const dbName = "wellnesspurelife";

// Only allow specific categories
const allowedCategories = ["fitness", "mindfulness", "nourish"];

// Capitalize the first letter to match collection naming convention
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// API route handler
export default async function handler(req, res) {
  const category = req.query.category?.toLowerCase();

  if (!category || !allowedCategories.includes(category)) {
    return res.status(400).json({ message: "Invalid or missing category" });
  }

  let client;

  try {
    // Connect to MongoDB
    client = await MongoClient.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    const db = client.db(dbName);

    // Example: quizFitnessResults, quizMindfulnessResults, etc.
    const collectionName = `quiz${capitalize(category)}Results`;

    // Get latest quiz result
    const latestResult = await db
      .collection(collectionName)
      .findOne({}, { sort: { createdAt: -1 } });

    if (!latestResult) {
      return res
        .status(404)
        .json({ message: `No ${category} quiz result found.` });
    }

    // Get quiz metadata (including recommendations)
    const quizMeta = await db.collection("quizzes").findOne({ slug: category });

    res.status(200).json({
      message: `Your ${category} plan is ready!`,
      answers: latestResult,
      recommendations: quizMeta?.recommendations || [],
    });
  } catch (error) {
    console.error("Result Fetch Error:", error);
    return res.status(500).json({ message: "Internal server error" });
  } finally {
    // Always close MongoDB connection
    if (client) {
      await client.close();
    }
  }
}
