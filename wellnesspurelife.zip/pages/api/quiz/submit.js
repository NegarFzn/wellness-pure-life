import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI;
const dbName = "wellnesspurelife";
const allowedCategories = ["fitness", "mindfulness", "nourish"];

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method Not Allowed" });
  }

  const category = req.query.category?.toLowerCase();

  if (!category || !allowedCategories.includes(category)) {
    return res.status(400).json({ message: "Invalid or missing category" });
  }

  let client;

  try {
    client = await MongoClient.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    const db = client.db(dbName);

    const collectionName = `quiz${capitalize(category)}Results`;
    const collection = db.collection(collectionName);

    const data = {
      ...req.body,
      category,
      createdAt: new Date(),
    };

    await collection.insertOne(data);

    return res.status(200).json({
      status: "success",
      message: `${capitalize(category)} quiz saved.`,
    });
  } catch (error) {
    console.error("MongoDB Insert Error:", error);
    return res.status(500).json({
      status: "error",
      message: "Database error.",
    });
  } finally {
    if (client) await client.close();
  }
}
