// pages/quizzes/category/[category].js
import PlanQuiz from "../../../components/Quiz/PlanQuiz";
import { MongoClient } from "mongodb";

export default function CategoryQuizPage({ category, steps }) {
  if (!steps || steps.length === 0) {
    return (
      <main style={{ padding: "2rem" }}>
        <h1>Quiz not found</h1>
        <p>No questions defined for “{category}”.</p>
      </main>
    );
  }

  const submitUrl = `/api/quiz/submit?category=${category}`;

  return <PlanQuiz submitUrl={submitUrl} steps={steps} category={category} />;
}

export async function getServerSideProps({ params }) {
  const category = String(params.category).toLowerCase();
  let client;

  try {
    client = await MongoClient.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    const db = client.db("wellnesspurelife");

    // Attempt to find quiz by slug (preferred) or fallback to category
    const quiz =
      (await db.collection("quizzes").findOne({ slug: category })) ||
      (await db.collection("quizzes").findOne({ category }));

    const steps = quiz?.questions ?? [];

    return {
      props: {
        category,
        steps,
      },
    };
  } catch (error) {
    console.error("Error loading quiz category:", error);
    return {
      props: {
        category,
        steps: [],
      },
    };
  } finally {
    if (client) await client.close();
  }
}
