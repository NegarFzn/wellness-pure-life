import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import classes from "./quizResult.module.css";

export default function QuizResultPage() {
  const { query } = useRouter();
  const category = String(query.category || "");
  const [data, setData] = useState(null);

  useEffect(() => {
    if (!category) return;
    (async () => {
      const res = await fetch(`/api/quiz/result?category=${category}`);
      const json = await res.json();
      setData(json);
    })();
  }, [category]);

  if (!data) return <main className={classes.container}>Loading result…</main>;
  if (data.message && !data.answers)
    return <main className={classes.container}>{data.message}</main>;

  const excludedKeys = ["_id", "createdAt", "category"];
  const filteredAnswers = Object.entries(data.answers).filter(
    ([key]) => !excludedKeys.includes(key)
  );

  return (
    <main className={classes.container}>
      <h1 className={classes.heading}>
        {(category?.[0] || "").toUpperCase() + category.slice(1)} – Your Result
      </h1>

      {/* Your Answers */}
      <section className={classes.answersBox}>
        <h2 className={classes.subheading}>Your Answers</h2>
        <ul className={classes.answerList}>
          {filteredAnswers.map(([key, value]) => (
            <li key={key} className={classes.answerItem}>
              <span className={classes.label}>
                {key.charAt(0).toUpperCase() + key.slice(1)}:
              </span>
              <span className={classes.value}>{String(value)}</span>
            </li>
          ))}
        </ul>
      </section>

      {/* Recommendations */}
      <section className={classes.recommendationBox}>
        <h2 className={classes.subheading}>Recommended Next Steps</h2>
        {data.recommendations?.length ? (
          <ul className={classes.recommendationsList}>
            {data.recommendations.map((r, i) => {
              return (
                <li key={i} className={classes.recommendationItem}>
                  {typeof r === "string" ? (
                    <span className={classes.value}>{r}</span>
                  ) : (
                    <>
                      <strong>{r.title}</strong>
                      <p>{r.content}</p>
                    </>
                  )}
                </li>
              );
            })}
          </ul>
        ) : (
          <p className={classes.noRecommendations}>No recommendations yet.</p>
        )}
      </section>
    </main>
  );
}
