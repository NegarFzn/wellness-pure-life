import React, { useState } from "react";
import { useRouter } from "next/router";
import classes from "./PlanQuiz.module.css";

export default function PlanQuiz({ submitUrl, steps = [], category }) {
  const router = useRouter();
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  if (!steps.length) {
    return (
      <div className={classes.quizStep}>
        <h2 className={classes.quizQuestion}>Quiz not available</h2>
        <p>Please try again later.</p>
      </div>
    );
  }

  const handleSelect = async (value) => {
    const key = steps[current].key;
    const updatedAnswers = { ...answers, [key]: value };
    setAnswers(updatedAnswers);

    if (current + 1 < steps.length) {
      setCurrent((prev) => prev + 1);
    } else {
      await submitQuiz(updatedAnswers);
    }
  };

  const submitQuiz = async (payload) => {
    setSubmitting(true);
    setError("");

    try {
      const response = await fetch(submitUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...payload,
          createdAt: new Date().toISOString(),
        }),
      });

      if (!response.ok) {
        throw new Error(`Submit failed with status ${response.status}`);
      }

      const targetUrl = category
        ? `/quizzes/result/${category}`
        : "/plans/result";

      router.push(targetUrl);
    } catch (err) {
      console.error("Submission error:", err);
      setError("Sorry, we couldn’t save your answers. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const { question, options } = steps[current];

  return (
    <div className={classes.quizStep}>
      <h2 className={classes.quizQuestion}>{question}</h2>

      <div className={classes.quizOptions}>
        {options.map((option) => (
          <button
            key={option}
            onClick={() => handleSelect(option)}
            className={classes.quizOptionButton}
            disabled={submitting}
            aria-disabled={submitting}
          >
            {option}
          </button>
        ))}
      </div>

      {error && <p className={classes.quizError}>{error}</p>}
      {submitting && <p className={classes.quizSaving}>Saving your answers…</p>}
    </div>
  );
}
